#!/bin/sh
java -jar amvconv.jar
